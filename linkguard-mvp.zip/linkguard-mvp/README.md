# LinkGuard MVP（リンクガード）  
**差分追跡（事故調査）× 参照破綻検知（復旧支援）** の“制作保険”ツールの最小実装です。  
Premiere / After Effects / Blender みたいな「リンク切れが致命傷」な現場で、**消えたのか・移したのか**を証拠ベースで辿って、**旧パスを再現して救出**します。

---

## できること（MVP）
- フォルダ監視 → **削除 / 移動 / リネーム / 更新** を SQLite に時系列で記録
- 走査 → ファイル指紋（Fingerprint）で **同一ファイルを追跡**
- `locate` → 「昔のパス」を入れると **現在地の候補**を出す（確度順）
- `emulate` → **旧パスを Junction / Symlink で再現**して、アプリ側の再リンクを不要にする（狙い）

---

## 安全設計
- LinkGuard は **勝手に削除しません**（読む・記録する・再現するだけ）
- `emulate` は「旧パスが存在しない」ことが前提です（上書きしない）

---

## クイックスタート（Windows / macOS）
### 1) セットアップ
```bash
# どこでもOK
cd linkguard-mvp
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS
# source .venv/bin/activate

pip install -r requirements.txt
pip install -e .
```

### 2) DB作成＋監視対象の登録（config）
```bash
# DBを作って、監視ルートを保存（例）
linkguard init --db "D:\linkguard\linkguard.sqlite" "D:\Projects" "E:\Assets"
```

### 3) まず一回スキャン（指紋の辞書づくり）
```bash
linkguard scan --mode fast
```

### 4) 監視スタート（Ctrl+Cで停止）
```bash
linkguard watch
```

---

## 典型：消えた/移動した素材を救う
### 1) 何が起きたか見る（タイムライン）
```bash
linkguard timeline --since 24h --limit 200
```

### 2) “昔のパス”から現在地を推測
```bash
linkguard locate "D:\mie\assets\bg\A.mov"
```

### 3) 旧パスを再現して、アプリ側のリンクを一気に復活
```bash
# 例：D:\mie を E:\archive\mie に移していた場合
linkguard emulate "D:\mie" "E:\archive\mie" --kind dir
```

---

## 指紋モード
- `quick`：速い（衝突リスクあり）  
- `fast`：速い＋強め（先頭/末尾1MiB + メタ情報） → **MVP標準**
- `strong`：最強（全読みハッシュ）→ 重いので必要なときだけ

---

## このMVPで未実装（次の段階）
- プロジェクトファイル（.aep / .prproj / .blend）を解析して「影響範囲」を直接出す
- GUI（Tauri/Electron）で Timeline / Impact / Proof を視覚化
- ドライブ UUID（macOS）など、ボリューム識別の精度アップ
- 重複イベントの更なる圧縮（長時間監視でDBが膨らむ対策）

---

## ライセンス
MIT
