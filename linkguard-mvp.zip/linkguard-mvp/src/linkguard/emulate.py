from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Literal, Tuple

def _run(cmd: str) -> Tuple[int, str]:
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    out = (p.stdout or "") + (p.stderr or "")
    return p.returncode, out.strip()

def create_path_emulation(old_path: Path, new_path: Path, kind: Literal["auto","file","dir"]="auto") -> dict:
    old_path = Path(old_path).expanduser()
    new_path = Path(new_path).expanduser()

    if kind == "auto":
        kind = "dir" if new_path.is_dir() else "file"

    if old_path.exists() or old_path.is_symlink():
        raise FileExistsError(f"old_path already exists: {old_path}")

    old_path.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        if kind == "dir":
            # Junction is the most reliable for creative project folder trees.
            code, out = _run(f'cmd /c mklink /J "{old_path}" "{new_path}"')
            if code == 0:
                return {"method": "junction", "old": str(old_path), "new": str(new_path), "output": out}
            # Fallback: symlink dir
            try:
                os.symlink(str(new_path), str(old_path), target_is_directory=True)
                return {"method": "symlink_dir", "old": str(old_path), "new": str(new_path), "output": out}
            except Exception as e:
                raise RuntimeError(f"Failed to create junction/symlink. mklink output: {out}") from e
        else:
            code, out = _run(f'cmd /c mklink "{old_path}" "{new_path}"')
            if code == 0:
                return {"method": "symlink_file_mklink", "old": str(old_path), "new": str(new_path), "output": out}
            try:
                os.symlink(str(new_path), str(old_path))
                return {"method": "symlink_file", "old": str(old_path), "new": str(new_path), "output": out}
            except Exception as e:
                raise RuntimeError(f"Failed to create symlink. mklink output: {out}") from e
    else:
        # macOS/Linux
        os.symlink(str(new_path), str(old_path))
        return {"method": "symlink", "old": str(old_path), "new": str(new_path), "output": ""}
