from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .db import DB

@dataclass
class Candidate:
    path: str
    score: float
    reason: str

def locate_by_old_path(db: DB, old_path: Path, limit: int = 10) -> tuple[Optional[str], list[Candidate]]:
    old_path = Path(old_path).expanduser()
    old = str(old_path)

    # 1) Direct fingerprint match by stored file record
    fp_row = db.find_fingerprint_by_path(old)
    if fp_row:
        fp, mode, size, mtime_ns = fp_row
        latest = db.find_latest_path_by_fingerprint(fp)
        if latest:
            if latest != old:
                return latest, [Candidate(path=latest, score=1.0, reason=f"fingerprint({mode}) match")]
            return old, [Candidate(path=old, score=1.0, reason="already present")]

    # 2) Try events table
    row = db.conn.execute(
        """
        SELECT fingerprint FROM events
        WHERE (src_path = ? OR dst_path = ?) AND fingerprint IS NOT NULL
        ORDER BY ts_utc DESC
        LIMIT 1
        """,
        (old, old),
    ).fetchone()
    if row and row["fingerprint"]:
        fp = row["fingerprint"]
        latest = db.find_latest_path_by_fingerprint(fp)
        if latest:
            return latest, [Candidate(path=latest, score=0.95, reason="event fingerprint match")]

    # 3) Heuristic search by basename
    name = old_path.name
    if not name:
        return None, []
    # Use LIKE match
    rows = db.conn.execute(
        """
        SELECT path, fingerprint, mode, size, mtime_ns, last_seen_utc
        FROM files
        WHERE path LIKE ?
        ORDER BY last_seen_utc DESC
        LIMIT 200
        """,
        (f"%{name}",),
    ).fetchall()

    cands: list[Candidate] = []
    for r in rows:
        p = r["path"]
        score = 0.40
        reason = "basename match"
        # small bonus if same extension and same parent folder name
        try:
            if Path(p).suffix == old_path.suffix:
                score += 0.10
        except Exception:
            pass
        # bonus if contains nearby folder names
        for part in old_path.parts[-4:-1]:
            if part and part in p:
                score += 0.05
        cands.append(Candidate(path=p, score=min(score, 0.90), reason=reason))

    cands.sort(key=lambda x: x.score, reverse=True)
    if cands:
        return cands[0].path, cands[:limit]
    return None, []
