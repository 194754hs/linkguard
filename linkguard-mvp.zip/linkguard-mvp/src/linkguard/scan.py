from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Literal, Optional

from .db import DB
from .fingerprint import stat_file, quick_fingerprint, fast_fingerprint, strong_fingerprint, volume_id_from_path
from .watcher import should_ignore

Mode = Literal["quick", "fast", "strong"]

def scan_roots(db: DB, roots: Iterable[Path], mode: Mode = "fast") -> dict[str, int]:
    roots = [Path(r).expanduser().resolve() for r in roots]
    scanned = 0
    skipped = 0
    errors = 0

    for root in roots:
        for dirpath, dirnames, filenames in os.walk(root):
            dp = Path(dirpath)
            if should_ignore(dp):
                dirnames[:] = []  # don't recurse
                skipped += 1
                continue

            # prune ignored dirs
            dirnames[:] = [d for d in dirnames if not should_ignore(dp / d)]

            for fn in filenames:
                p = dp / fn
                if should_ignore(p):
                    skipped += 1
                    continue
                try:
                    info = stat_file(p)
                    if mode == "quick":
                        fp = quick_fingerprint(info)
                    elif mode == "fast":
                        fp, _ = fast_fingerprint(p, info)
                    else:
                        fp, _ = strong_fingerprint(p, info)
                    vid = volume_id_from_path(p)
                    db.upsert_file(fingerprint=fp, mode=mode, size=info.size, mtime_ns=info.mtime_ns, path=str(p), volume_id=vid)
                    scanned += 1
                except Exception:
                    errors += 1

        db.commit()

    return {"scanned": scanned, "skipped": skipped, "errors": errors}
