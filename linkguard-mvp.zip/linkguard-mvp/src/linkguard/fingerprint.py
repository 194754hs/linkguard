from __future__ import annotations

import os
import ctypes
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Literal, Tuple

from blake3 import blake3

Mode = Literal["quick", "fast", "strong"]

CHUNK = 1024 * 1024  # 1 MiB

def _win_volume_serial(root: str) -> Optional[str]:
    try:
        GetVolumeInformationW = ctypes.windll.kernel32.GetVolumeInformationW
        GetVolumeInformationW.argtypes = [
            wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
            ctypes.POINTER(wintypes.DWORD),
            ctypes.POINTER(wintypes.DWORD),
            wintypes.LPWSTR, wintypes.DWORD
        ]
        GetVolumeInformationW.restype = wintypes.BOOL

        vol_name = ctypes.create_unicode_buffer(261)
        fs_name = ctypes.create_unicode_buffer(261)
        serial = wintypes.DWORD()
        max_comp = wintypes.DWORD()
        flags = wintypes.DWORD()

        ok = GetVolumeInformationW(
            root, vol_name, 261,
            ctypes.byref(serial),
            ctypes.byref(max_comp),
            ctypes.byref(flags),
            fs_name, 261
        )
        if not ok:
            return None
        return f"{serial.value:08X}"
    except Exception:
        return None

def volume_id_from_path(path: Path) -> Optional[str]:
    """
    Best-effort volume identifier.
    - Windows: 'C:' + volume serial (if available)
    - Others: mount root (coarse)
    """
    try:
        p = Path(path).resolve()
    except Exception:
        p = Path(path)

    if os.name == "nt":
        drive = os.path.splitdrive(str(p))[0]  # 'C:'
        if not drive:
            return None
        root = drive + "\\"
        serial = _win_volume_serial(root)
        return f"{drive}:{serial}" if serial else drive
    else:
        # Coarse: just root. (Later: parse mount table / UUID)
        return "/"

@dataclass(frozen=True)
class FileInfo:
    path: Path
    size: int
    mtime_ns: int

def stat_file(path: Path) -> FileInfo:
    st = path.stat()
    return FileInfo(path=path, size=int(st.st_size), mtime_ns=int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9))))

def quick_fingerprint(info: FileInfo) -> str:
    # Cheap identity (NOT collision-safe). Good for first-pass indexing.
    h = blake3()
    h.update(str(info.size).encode("utf-8"))
    h.update(b":")
    h.update(str(info.mtime_ns).encode("utf-8"))
    return "q_" + h.hexdigest(length=16)

def fast_fingerprint(path: Path, info: Optional[FileInfo] = None) -> Tuple[str, FileInfo]:
    if info is None:
        info = stat_file(path)
    size = info.size
    h = blake3()
    h.update(str(size).encode("utf-8"))
    h.update(b":")
    h.update(str(info.mtime_ns).encode("utf-8"))
    with path.open("rb") as f:
        if size <= 2 * CHUNK:
            h.update(f.read())
        else:
            h.update(f.read(CHUNK))
            f.seek(max(0, size - CHUNK))
            h.update(f.read(CHUNK))
    return "f_" + h.hexdigest(length=32), info

def strong_fingerprint(path: Path, info: Optional[FileInfo] = None) -> Tuple[str, FileInfo]:
    if info is None:
        info = stat_file(path)
    h = blake3()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return "s_" + h.hexdigest(), info
