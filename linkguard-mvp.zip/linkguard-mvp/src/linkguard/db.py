from __future__ import annotations

import json
import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional, Tuple
from datetime import datetime, timezone

SCHEMA_VERSION = 1

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

@dataclass
class DB:
    path: Path
    conn: sqlite3.Connection

    @classmethod
    def open(cls, path: Path) -> "DB":
        path = Path(path).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        db = cls(path=path, conn=conn)
        db._migrate()
        return db

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    def _migrate(self) -> None:
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS meta (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL
            );
        """)
        row = self.conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
        ver = int(row["value"]) if row else 0

        if ver < 1:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS files (
                  fingerprint TEXT NOT NULL,
                  mode TEXT NOT NULL, -- quick|fast|strong
                  size INTEGER NOT NULL,
                  mtime_ns INTEGER NOT NULL,
                  path TEXT NOT NULL,
                  volume_id TEXT,
                  last_seen_utc TEXT NOT NULL,
                  PRIMARY KEY (fingerprint, path)
                );

                CREATE INDEX IF NOT EXISTS idx_files_fp ON files(fingerprint);
                CREATE INDEX IF NOT EXISTS idx_files_path ON files(path);

                CREATE TABLE IF NOT EXISTS events (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts_utc TEXT NOT NULL,
                  kind TEXT NOT NULL, -- created|deleted|moved|renamed|modified
                  src_path TEXT,
                  dst_path TEXT,
                  fingerprint TEXT,
                  size INTEGER,
                  details_json TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts_utc);
                CREATE INDEX IF NOT EXISTS idx_events_fp ON events(fingerprint);
                CREATE INDEX IF NOT EXISTS idx_events_src ON events(src_path);
                CREATE INDEX IF NOT EXISTS idx_events_dst ON events(dst_path);
            """)
            self.conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))
            self.conn.commit()

    def upsert_file(self, *, fingerprint: str, mode: str, size: int, mtime_ns: int, path: str, volume_id: Optional[str]) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO files(fingerprint, mode, size, mtime_ns, path, volume_id, last_seen_utc)
            VALUES(?,?,?,?,?,?,?)
            """,
            (fingerprint, mode, int(size), int(mtime_ns), path, volume_id, utc_now_iso()),
        )

    def insert_event(
        self,
        *,
        kind: str,
        src_path: Optional[str],
        dst_path: Optional[str],
        fingerprint: Optional[str],
        size: Optional[int],
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        self.conn.execute(
            """
            INSERT INTO events(ts_utc, kind, src_path, dst_path, fingerprint, size, details_json)
            VALUES(?,?,?,?,?,?,?)
            """,
            (utc_now_iso(), kind, src_path, dst_path, fingerprint, size, json.dumps(details, ensure_ascii=False) if details else None),
        )

    def commit(self) -> None:
        self.conn.commit()

    def find_latest_path_by_fingerprint(self, fingerprint: str) -> Optional[str]:
        row = self.conn.execute(
            """
            SELECT path, last_seen_utc
            FROM files
            WHERE fingerprint = ?
            ORDER BY last_seen_utc DESC
            LIMIT 1
            """,
            (fingerprint,),
        ).fetchone()
        return row["path"] if row else None

    def find_fingerprint_by_path(self, path: str) -> Optional[Tuple[str, str, int, int]]:
        row = self.conn.execute(
            """
            SELECT fingerprint, mode, size, mtime_ns
            FROM files
            WHERE path = ?
            ORDER BY last_seen_utc DESC
            LIMIT 1
            """,
            (path,),
        ).fetchone()
        if not row:
            return None
        return (row["fingerprint"], row["mode"], int(row["size"]), int(row["mtime_ns"]))

    def query_events(self, *, limit: int = 200, since_utc: Optional[str] = None) -> list[sqlite3.Row]:
        if since_utc:
            return list(self.conn.execute(
                "SELECT * FROM events WHERE ts_utc >= ? ORDER BY ts_utc DESC LIMIT ?",
                (since_utc, int(limit)),
            ).fetchall())
        return list(self.conn.execute(
            "SELECT * FROM events ORDER BY ts_utc DESC LIMIT ?",
            (int(limit),),
        ).fetchall())
