from __future__ import annotations

import os
import time
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Iterable

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileMovedEvent, FileDeletedEvent, FileCreatedEvent, FileModifiedEvent, DirMovedEvent, DirDeletedEvent, DirCreatedEvent, DirModifiedEvent

from .db import DB
from .fingerprint import stat_file, fast_fingerprint, quick_fingerprint, volume_id_from_path

DEFAULT_IGNORES = {
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
}

DEFAULT_IGNORE_DIRS = {
    ".git",
    "__pycache__",
    "node_modules",
    ".cache",
    ".Trash",
    "$RECYCLE.BIN",
    "System Volume Information",
}

def should_ignore(path: Path) -> bool:
    parts = set(path.parts)
    if any(p in DEFAULT_IGNORE_DIRS for p in parts):
        return True
    if path.name in DEFAULT_IGNORES:
        return True
    # temp files
    name = path.name
    if name.endswith("~") or name.endswith(".tmp") or name.endswith(".temp"):
        return True
    return False

@dataclass
class WatchSession:
    db: DB
    roots: list[Path]
    recursive: bool = True

class _Handler(FileSystemEventHandler):
    def __init__(self, session: WatchSession):
        self.s = session
        self._last: dict[str, float] = {}

    def _dedupe(self, key: str, window: float = 0.25) -> bool:
        now = time.monotonic()
        prev = self._last.get(key, 0.0)
        self._last[key] = now
        return (now - prev) < window

    def _record_existing_file(self, path: Path) -> Optional[str]:
        try:
            info = stat_file(path)
        except Exception:
            return None
        try:
            fp, _ = fast_fingerprint(path, info)
            vid = volume_id_from_path(path)
            self.s.db.upsert_file(fingerprint=fp, mode="fast", size=info.size, mtime_ns=info.mtime_ns, path=str(path), volume_id=vid)
            return fp
        except Exception:
            # fallback: quick only
            try:
                q = quick_fingerprint(info)
                vid = volume_id_from_path(path)
                self.s.db.upsert_file(fingerprint=q, mode="quick", size=info.size, mtime_ns=info.mtime_ns, path=str(path), volume_id=vid)
                return q
            except Exception:
                return None

    def on_created(self, event):
        p = Path(event.src_path)
        if should_ignore(p) or self._dedupe(f"c:{event.src_path}:{event.is_directory}"):
            return
        fp = None
        size = None
        if not event.is_directory:
            fp = self._record_existing_file(p)
            try:
                size = p.stat().st_size
            except Exception:
                size = None
        self.s.db.insert_event(kind="created", src_path=str(p), dst_path=None, fingerprint=fp, size=size, details={"is_dir": bool(event.is_directory)})
        self.s.db.commit()

    def on_deleted(self, event):
        p = Path(event.src_path)
        if should_ignore(p) or self._dedupe(f"d:{event.src_path}:{event.is_directory}"):
            return
        self.s.db.insert_event(kind="deleted", src_path=str(p), dst_path=None, fingerprint=None, size=None, details={"is_dir": bool(event.is_directory)})
        self.s.db.commit()

    def on_modified(self, event):
        p = Path(event.src_path)
        if should_ignore(p) or self._dedupe(f"m:{event.src_path}:{event.is_directory}"):
            return
        # avoid directory modified spam
        if event.is_directory:
            return
        fp = self._record_existing_file(p)
        try:
            size = p.stat().st_size
        except Exception:
            size = None
        self.s.db.insert_event(kind="modified", src_path=str(p), dst_path=None, fingerprint=fp, size=size, details={"is_dir": False})
        self.s.db.commit()

    def on_moved(self, event):
        src = Path(event.src_path)
        dst = Path(event.dest_path)
        if should_ignore(src) or should_ignore(dst) or self._dedupe(f"mv:{event.src_path}->{event.dest_path}:{event.is_directory}"):
            return
        fp = None
        size = None
        if not event.is_directory:
            fp = self._record_existing_file(dst)
            try:
                size = dst.stat().st_size
            except Exception:
                size = None
        kind = "renamed" if src.parent == dst.parent else "moved"
        self.s.db.insert_event(kind=kind, src_path=str(src), dst_path=str(dst), fingerprint=fp, size=size, details={"is_dir": bool(event.is_directory)})
        self.s.db.commit()

def start_watch(db: DB, roots: Iterable[Path], recursive: bool = True) -> Observer:
    roots = [Path(r).expanduser().resolve() for r in roots]
    session = WatchSession(db=db, roots=roots, recursive=recursive)
    handler = _Handler(session)
    obs = Observer()
    for r in roots:
        obs.schedule(handler, str(r), recursive=recursive)
    obs.start()
    return obs
