from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Any
import yaml

DEFAULT_CONFIG_PATH = Path.home() / ".linkguard.yml"

@dataclass
class Config:
    db: Path
    roots: list[Path]

def load_config(path: Path = DEFAULT_CONFIG_PATH) -> Optional[Config]:
    p = Path(path).expanduser()
    if not p.exists():
        return None
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    db = Path(data.get("db", "linkguard.sqlite")).expanduser()
    roots = [Path(x).expanduser() for x in (data.get("roots") or [])]
    return Config(db=db, roots=roots)

def save_config(cfg: Config, path: Path = DEFAULT_CONFIG_PATH) -> Path:
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {"db": str(cfg.db), "roots": [str(r) for r in cfg.roots]}
    p.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return p
