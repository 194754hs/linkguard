from __future__ import annotations

import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, List

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .db import DB
from .scan import scan_roots
from .watcher import start_watch
from .locate import locate_by_old_path
from .emulate import create_path_emulation
from .config import Config, load_config, save_config, DEFAULT_CONFIG_PATH

app = typer.Typer(add_completion=False, no_args_is_help=True)
console = Console()

def _parse_since(s: Optional[str]) -> Optional[str]:
    if not s:
        return None
    s = s.strip()
    # ISO passthrough
    if re.match(r"^\d{4}-\d{2}-\d{2}T", s):
        return s
    m = re.match(r"^(\d+)\s*([smhdw])$", s, re.IGNORECASE)
    if not m:
        raise typer.BadParameter("since must be ISO8601 or like 15m / 24h / 7d / 2w")
    n = int(m.group(1))
    unit = m.group(2).lower()
    delta = {
        "s": timedelta(seconds=n),
        "m": timedelta(minutes=n),
        "h": timedelta(hours=n),
        "d": timedelta(days=n),
        "w": timedelta(weeks=n),
    }[unit]
    ts = datetime.now(timezone.utc) - delta
    return ts.isoformat(timespec="seconds")

def _db_path_or_cfg(db: Optional[Path]) -> Path:
    if db:
        return Path(db).expanduser()
    cfg = load_config()
    if cfg:
        return cfg.db
    return Path("linkguard.sqlite")

@app.command()
def init(
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path (default: config or ./linkguard.sqlite)"),
    roots: List[Path] = typer.Argument(None, help="Optional roots to save into config"),
):
    """Create DB and optional config (~/.linkguard.yml)."""
    dbp = _db_path_or_cfg(db)
    d = DB.open(dbp)
    d.close()
    if roots:
        cfg = Config(db=dbp, roots=[Path(r).expanduser() for r in roots])
        p = save_config(cfg)
        console.print(f"[bold green]OK[/] DB created: {dbp}")
        console.print(f"[bold green]OK[/] Config saved: {p}")
    else:
        console.print(f"[bold green]OK[/] DB created: {dbp}")

@app.command()
def scan(
    roots: List[Path] = typer.Argument(None, help="Roots to scan (omit to use config roots)"),
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path"),
    mode: str = typer.Option("fast", "--mode", help="quick|fast|strong"),
):
    """Scan file trees and index fingerprints into DB."""
    dbp = _db_path_or_cfg(db)
    cfg = load_config()
    scan_roots_list = roots or (cfg.roots if cfg else [])
    if not scan_roots_list:
        console.print("[bold red]No roots.[/] Pass roots or run: linkguard init --db ... <roots...>")
        raise typer.Exit(code=2)

    d = DB.open(dbp)
    res = scan_roots(d, scan_roots_list, mode=mode)  # type: ignore
    d.close()
    console.print(f"[bold green]SCAN[/] scanned={res['scanned']} skipped={res['skipped']} errors={res['errors']}")

@app.command()
def watch(
    roots: List[Path] = typer.Argument(None, help="Roots to watch (omit to use config roots)"),
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Watch recursively"),
):
    """Watch roots and record timeline events into DB (Ctrl+C to stop)."""
    dbp = _db_path_or_cfg(db)
    cfg = load_config()
    watch_roots = roots or (cfg.roots if cfg else [])
    if not watch_roots:
        console.print("[bold red]No roots.[/] Pass roots or set config via init.")
        raise typer.Exit(code=2)

    d = DB.open(dbp)
    obs = start_watch(d, watch_roots, recursive=recursive)
    console.print(f"[bold green]WATCHING[/] DB={dbp}")
    for r in watch_roots:
        console.print(f"  • {Path(r).expanduser().resolve()}")

    try:
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Stopping...[/]")
    finally:
        try:
            obs.stop()
            obs.join(timeout=5)
        except Exception:
            pass
        d.close()
        console.print("[bold green]OK[/] stopped.")

@app.command()
def timeline(
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path"),
    limit: int = typer.Option(50, "--limit", min=1, max=500),
    since: Optional[str] = typer.Option(None, "--since", help="ISO8601 UTC or like 24h / 7d / 2w"),
):
    """Show recent events."""
    dbp = _db_path_or_cfg(db)
    d = DB.open(dbp)
    since_utc = _parse_since(since)
    rows = d.query_events(limit=limit, since_utc=since_utc)
    d.close()

    table = Table(title="LinkGuard Timeline (UTC)", box=box.SIMPLE_HEAVY)
    table.add_column("ts_utc", style="dim", no_wrap=True)
    table.add_column("kind", style="bold")
    table.add_column("src")
    table.add_column("dst")
    table.add_column("fp", style="cyan", no_wrap=True)

    for r in rows:
        fp = r["fingerprint"] or ""
        if fp and len(fp) > 14:
            fp = fp[:14] + "…"
        table.add_row(
            r["ts_utc"],
            r["kind"],
            (r["src_path"] or "")[-80:],
            (r["dst_path"] or "")[-80:],
            fp,
        )
    console.print(table)

@app.command()
def locate(
    old_path: Path = typer.Argument(..., help="Old missing path (string you remember / from app relink dialog)"),
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path"),
    limit: int = typer.Option(10, "--limit", min=1, max=50),
):
    """Given an old path, guess the current path (best-effort)."""
    dbp = _db_path_or_cfg(db)
    d = DB.open(dbp)
    best, cands = locate_by_old_path(d, old_path, limit=limit)
    d.close()

    if not cands:
        console.print("[bold red]No candidates.[/]")
        raise typer.Exit(code=1)

    table = Table(title="Relink Candidates", box=box.SIMPLE_HEAVY)
    table.add_column("score", justify="right")
    table.add_column("reason")
    table.add_column("path")
    for c in cands:
        table.add_row(f"{c.score:.2f}", c.reason, c.path)
    console.print(table)

    console.print(f"[bold green]BEST[/] {best}")

@app.command()
def emulate(
    old_path: Path = typer.Argument(..., help="Old path to be emulated (must NOT exist)"),
    new_path: Path = typer.Argument(..., help="Current real path (must exist)"),
    kind: str = typer.Option("auto", "--kind", help="auto|file|dir"),
):
    """Create path emulation (junction/symlink) so apps can find the old path again."""
    res = create_path_emulation(old_path, new_path, kind=kind)  # type: ignore
    table = Table(title="Path Emulation", box=box.SIMPLE_HEAVY)
    table.add_column("method")
    table.add_column("old")
    table.add_column("new")
    table.add_row(res["method"], res["old"], res["new"])
    console.print(table)
    if res.get("output"):
        console.print(res["output"])

@app.command()
def config_show():
    """Show current config (~/.linkguard.yml)."""
    cfg = load_config()
    if not cfg:
        console.print(f"[bold yellow]No config.[/] expected at {DEFAULT_CONFIG_PATH}")
        raise typer.Exit(code=1)
    console.print(f"[bold]db[/]   {cfg.db}")
    console.print("[bold]roots[/]")
    for r in cfg.roots:
        console.print(f"  • {r}")

@app.command()
def config_set(
    db: Optional[Path] = typer.Option(None, "--db", help="SQLite DB path"),
    roots: List[Path] = typer.Argument(..., help="Roots (one or more)"),
):
    """Set config (~/.linkguard.yml)."""
    dbp = _db_path_or_cfg(db)
    cfg = Config(db=dbp, roots=[Path(r).expanduser() for r in roots])
    p = save_config(cfg)
    console.print(f"[bold green]OK[/] Config saved: {p}")
